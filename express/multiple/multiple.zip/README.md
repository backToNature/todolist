## 目录上传

根目录执行```node app.js```

打开http://localhost:3000，执行上传就行